<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo URLROOT; ?>/css/admin-style/view.css">
    <script src="https://kit.fontawesome.com/74174153b4.js" crossorigin="anonymous"></script>
    <title><?php echo SITENAME; ?></title>
</head>

<body>

    <?php require APPROOT . '/views/inc/admin_navbar.php' ?>

    <div class="main">
        <div class="content-heading">
            <h1>Staff members</h1>
            <hr>
        </div>

        <button class="add-new-staff-member-box">

            <div class="button-name">
                <a href="<?php echo URLROOT; ?>/Admin_add_staff_member/add_staff_member" class="grid-items">
                    <i class="fa-solid fa-user-tie"></i>
                    <p>Staff members</p>
                </a>
            </div>
        </button>

        <div class="content-table">
            <table class="full-table">
                <tr>
                    <th>Staff Id</th>
                    <th>NIC</th>
                    <th>First name</th>
                    <th>Last name</th>
                    <th>DOB</th>
                    <th>Address</th>
                    <th>Email</th>
                    <th>Mobile no</th>
                    <th>Telephone no</th>
                </tr>

                <?php foreach ($data['staffmembers'] as $staffmembers) : ?>
                    <tr>
                        <td><?php echo $staffmembers->emp_id; ?></td>
                        <td><?php echo $staffmembers->nic; ?></td>
                        <td><?php echo $staffmembers->fname; ?></td>
                        <td><?php echo $staffmembers->lname; ?></td>
                        <td><?php echo $staffmembers->dob; ?></td>
                        <td><?php echo $staffmembers->address; ?></td>
                        <td><?php echo $staffmembers->email; ?></td>
                        <td><?php echo $staffmembers->mobileNo; ?></td>
                        <td><?php echo $staffmembers->telNo; ?></td>

                    </tr>
                <?php endforeach; ?>


            </table>

        </div>

    </div>

    <script src="<?php echo URLROOT; ?>/js/admin/staffhome.js"></script>



</body>

</html>