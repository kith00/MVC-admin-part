<?php

class Admin_remove_bus_driver extends Controller{

    public function __construct()
    {
        
    }

    public function view_remove_bus_driver(){

        $this->view('admin/remove_bus_driver');
    }
}

?>