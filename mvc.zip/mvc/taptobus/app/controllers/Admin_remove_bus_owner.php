<?php
class Admin_remove_bus_owner extends Controller{

    public function __construct()
    {
        
    }

    public function view_remove_bus_owner(){
        $this->view('admin/remove_bus_owner');
    }
}
?>