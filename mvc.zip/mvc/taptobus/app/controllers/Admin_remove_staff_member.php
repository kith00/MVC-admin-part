<?php

class Admin_remove_staff_member extends Controller{

    public function __construct()
    {
        
    }

    public  function view_remove_staff_member(){
        $this->view('admin/remove_staff_member');
    }
}

?>