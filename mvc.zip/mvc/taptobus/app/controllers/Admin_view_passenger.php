<?php

class Admin_view_passenger extends Controller{
    public function __construct()
    {
        
    }

    public function view_passenger (){
        $this->view('admin/view_passenger');
    }
}

?>