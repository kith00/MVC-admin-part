<?php
class Admin_remove_bus_conductor extends Controller{

    public function __construct()
    {
        
    }

    public function view_remove_bus_conductor(){

        $this->view('admin/remove_bus_conductor');

    }
}

?>