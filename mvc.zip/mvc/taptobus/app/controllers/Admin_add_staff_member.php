<?php
class Admin_add_staff_member extends Controller{



    public function __construct()
    {
        
        
    }

    public function add_staff_member(){

        $this->view('admin/add_new_staff_member');

    }
}

?>