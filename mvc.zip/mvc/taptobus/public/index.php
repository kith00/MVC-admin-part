<?php

// load the bootstrap.php file
require_once '../app/bootstrap.php';

// instantiate the Core library
$init = new Core;